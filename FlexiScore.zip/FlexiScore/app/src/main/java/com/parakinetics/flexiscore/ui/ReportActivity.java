package com.parakinetics.flexiscore.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.parakinetics.flexiscore.R;
import com.parakinetics.flexiscore.data.AssessmentResult;
import com.parakinetics.flexiscore.pdf.ClassificationPdfReport;
import java.io.File;

public class ReportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        TextView tvSummary = findViewById(R.id.tvSummary);
        Button btnExportPdf = findViewById(R.id.btnExportPdf);

        // Generate Mock Data (Since we aren't using the camera yet)
        AssessmentResult mockResult = new AssessmentResult();
        mockResult.athleteId = "DEMO-ATHLETE-99";
        mockResult.leftPeakAngle = 145.5f;
        mockResult.rightPeakAngle = 110.0f;
        mockResult.symmetryDeficitPercent = 24.3f;
        mockResult.cheatDetected = false;

        tvSummary.setText("Left: " + mockResult.leftPeakAngle + "°\n" +
                "Right: " + mockResult.rightPeakAngle + "°\n" +
                "Deficit: " + mockResult.symmetryDeficitPercent + "%");

        // Button Click triggers PDF generation
        btnExportPdf.setOnClickListener(v -> {
            try {
                File pdf = ClassificationPdfReport.generateReport(this, mockResult);
                Toast.makeText(this, "Saved to Downloads: " + pdf.getName(), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to generate PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}