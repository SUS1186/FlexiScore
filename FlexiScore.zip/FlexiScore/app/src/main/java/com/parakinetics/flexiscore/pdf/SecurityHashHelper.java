package com.parakinetics.flexiscore.pdf;

import android.graphics.Bitmap;
import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import com.parakinetics.flexiscore.data.AssessmentResult;
import java.security.MessageDigest;

public class SecurityHashHelper {

    public static String generateHash(AssessmentResult result) {
        try {
            // Combine core data to create a unique fingerprint
            String rawData = result.athleteId + result.leftPeakAngle + result.rightPeakAngle + result.timestamp;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(rawData.getBytes("UTF-8"));

            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString().substring(0, 16); // Return a 16-character short hash
        } catch (Exception e) {
            return "HASH_ERROR";
        }
    }

    public static Bitmap generateQRCode(String content) {
        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            return barcodeEncoder.encodeBitmap(content, BarcodeFormat.QR_CODE, 400, 400);
        } catch (Exception e) {
            return null;
        }
    }
}