package com.parakinetics.flexiscore.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface AssessmentDao {
    @Insert
    void insert(AssessmentRecord record);

    @Query("SELECT * FROM assessment_history ORDER BY timestamp DESC")
    List<AssessmentRecord> getAllAssessments();
}