package com.parakinetics.flexiscore.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "assessment_history")
public class AssessmentRecord {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String athleteId;
    public String jointType;
    public float leftPeakAngle;
    public float rightPeakAngle;
    public float symmetryDeficitPercent;
    public boolean cheatDetected;
    public long timestamp;
}