package com.parakinetics.flexiscore.pdf;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Environment;
import com.parakinetics.flexiscore.data.AssessmentResult;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ClassificationPdfReport {

    public static File generateReport(Context context, AssessmentResult result) throws IOException {
        PdfDocument document = new PdfDocument();
        // Create an A4 sized page (595 x 842 PostScript points)
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();

        // 1. Draw Title
        paint.setColor(Color.BLACK);
        paint.setTextSize(24f);
        paint.setFakeBoldText(true);
        canvas.drawText("IPC Classification Goniometry Report", 50, 80, paint);

        // 2. Draw Data
        paint.setTextSize(16f);
        paint.setFakeBoldText(false);
        canvas.drawText("Athlete ID: " + result.athleteId, 50, 140, paint);
        canvas.drawText("Left Angle: " + result.leftPeakAngle + "°", 50, 170, paint);
        canvas.drawText("Right Angle: " + result.rightPeakAngle + "°", 50, 200, paint);
        canvas.drawText("Symmetry Deficit: " + result.symmetryDeficitPercent + "%", 50, 230, paint);

        // Highlight cheat warnings in RED
        if (result.cheatDetected) {
            paint.setColor(Color.RED);
            paint.setFakeBoldText(true);
        }
        canvas.drawText("Integrity Warning: " + (result.cheatDetected ? "YES (Manual Review Required)" : "None"), 50, 260, paint);
        paint.setColor(Color.BLACK);
        paint.setFakeBoldText(false);

        // 3. Draw Security QR Code
        String hash = SecurityHashHelper.generateHash(result);
        Bitmap qrCode = SecurityHashHelper.generateQRCode(hash);
        if (qrCode != null) {
            canvas.drawBitmap(qrCode, 350, 100, paint);
            paint.setTextSize(10f);
            canvas.drawText("Verification Hash:", 350, 520, paint);
            canvas.drawText(hash, 350, 535, paint);
        }

        document.finishPage(page);

        // 4. Save to the device's public Downloads folder
        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File file = new File(downloadsDir, "FlexiScore_" + result.athleteId + ".pdf");

        FileOutputStream fos = new FileOutputStream(file);
        document.writeTo(fos);
        document.close();
        fos.close();

        return file;
    }
}